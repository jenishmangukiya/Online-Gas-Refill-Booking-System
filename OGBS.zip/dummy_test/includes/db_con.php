<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gas_book_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
?>